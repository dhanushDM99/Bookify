from django.contrib import admin
from .models import order
# Register your models here.
admin.site.register(order)