# library_web_project
A website for library management using MYSQL and django
